package com.reto5.app_inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
